package com.example.curs;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CustomArrayAdapter extends ArrayAdapter<ListItemClass> {
    private LayoutInflater inflater;
    private List<ListItemClass> listItem = new ArrayList<>();

    public CustomArrayAdapter(@NonNull Context context, int resourse, List<ListItemClass> listItem,
                              LayoutInflater inflater) {
        super(context, resourse, listItem);
        this.inflater = inflater;
        this.listItem = listItem;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder viewHolder;
        ListItemClass listItemClass = listItem.get(position);
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.list_item, null, false);
            viewHolder = new ViewHolder();
            viewHolder.data_1 = convertView.findViewById(R.id.textView);
            viewHolder.data_2 = convertView.findViewById(R.id.textView2);
            viewHolder.data_3 = convertView.findViewById(R.id.textView3);
            viewHolder.data_4 = convertView.findViewById(R.id.textView4);
        }
        else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.data_1.setText(listItemClass.getData_1());
        viewHolder.data_2.setText(listItemClass.getData_2());
        viewHolder.data_3.setText(listItemClass.getData_3());
        viewHolder.data_4.setText(listItemClass.getData_4());
        return convertView;
    }

    private class ViewHolder {
        TextView data_1;
        TextView data_2;
        TextView data_3;
        TextView data_4;
    }
}
